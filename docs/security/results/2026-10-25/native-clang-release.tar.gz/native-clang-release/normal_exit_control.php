<?php
if (!php56_probe_arm_atexit("/work/.security-build/results/native-clang-release/normal_exit_control.native-atexit.marker")) { exit(90); }
register_shutdown_function(function () { file_put_contents("/work/.security-build/results/native-clang-release/normal_exit_control.php-shutdown.marker", "php-shutdown\n"); });
echo "normal\n";

<?php
if (!php56_probe_arm_atexit("/work/.security-build/results/native-clang-release/ordinary_fatal_control.native-atexit.marker")) { exit(90); }
register_shutdown_function(function () { file_put_contents("/work/.security-build/results/native-clang-release/ordinary_fatal_control.php-shutdown.marker", "php-shutdown\n"); });
trigger_error("ordinary-fatal-control", E_USER_ERROR);

<?php
if (!php56_probe_arm_atexit("/work/.security-build/results/native-clang-release/safe_string_int_max.native-atexit.marker")) { exit(90); }
register_shutdown_function(function () { file_put_contents("/work/.security-build/results/native-clang-release/safe_string_int_max.php-shutdown.marker", "php-shutdown\n"); });
php56_probe_boundary("safe_string_int_max");

<?php
if (!php56_probe_arm_atexit("/work/.security-build/results/native-clang-release/synthetic_add_char.native-atexit.marker")) { exit(90); }
register_shutdown_function(function () { file_put_contents("/work/.security-build/results/native-clang-release/synthetic_add_char.php-shutdown.marker", "php-shutdown\n"); });
php56_probe_boundary("synthetic_add_char");

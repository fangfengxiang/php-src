<?php
define('EVIDENCE_DIR', '/work/.security-build/results/fpm-baseline-early/fpm-gaul369v');
header('Content-Type: application/json');
function answer($values) {
    $values['pid'] = getmypid();
    $values['php_version'] = PHP_VERSION;
    $values['sapi'] = PHP_SAPI;
    echo json_encode($values), "\n";
}
function started($name) {
    file_put_contents(EVIDENCE_DIR . '/' . $name . '.started.json',
        json_encode(array('pid' => getmypid(), 'memory_limit' => ini_get('memory_limit'))));
}
$action = isset($_GET['action']) ? $_GET['action'] : 'probe';
switch ($action) {
case 'probe':
    answer(array('ok' => true, 'iconv' => extension_loaded('iconv'),
        'session' => extension_loaded('session'), 'json' => extension_loaded('json'),
        'upload_progress_ini' => ini_get('session.upload_progress.enabled')));
    break;
case 'session-write':
    session_start();
    $_SESSION['ordinary'] = array('value' => 'retained', 'count' => 1);
    $sid = session_id();
    session_write_close();
    answer(array('session_id' => $sid));
    break;
case 'session-read':
    session_start();
    $values = $_SESSION;
    $sid = session_id();
    session_write_close();
    answer(array('session_id' => $sid, 'values' => $values));
    break;
case 'upload':
    session_start();
    $progress = isset($_SESSION['upload_progress_security-test']);
    $ordinary = isset($_SESSION['ordinary']) ? $_SESSION['ordinary'] : null;
    session_write_close();
    $upload = isset($_FILES['sample']) ? $_FILES['sample'] : null;
    $valid = $upload && $upload['error'] === UPLOAD_ERR_OK;
    answer(array('field' => isset($_POST['field']) ? $_POST['field'] : null,
        'progress_exists' => $progress, 'ordinary_session' => $ordinary,
        'upload_progress_ini' => ini_get('session.upload_progress.enabled'),
        'filename' => $upload ? $upload['name'] : null,
        'upload_error' => $upload ? $upload['error'] : null,
        'size' => $upload ? $upload['size'] : null,
        'is_uploaded_file' => $valid && is_uploaded_file($upload['tmp_name']),
        'contents' => $valid ? file_get_contents($upload['tmp_name']) : null));
    break;
case 'fatal':
    register_shutdown_function(function () {
        file_put_contents(EVIDENCE_DIR . '/ordinary.shutdown.marker',
            (string)getmypid() . "\n", FILE_APPEND);
    });
    started('ordinary');
    trigger_error('PHP56_FPM_ORDINARY_FATAL', E_USER_ERROR);
    echo 'UNREACHABLE';
    break;
case 'seed-handlers':
    set_error_handler(function ($number, $message) {
        file_put_contents(EVIDENCE_DIR . '/previous-handler.marker', $message . "\n", FILE_APPEND);
        return false;
    });
    set_exception_handler(function ($exception) {
        file_put_contents(EVIDENCE_DIR . '/previous-exception-handler.marker',
            $exception->getMessage() . "\n", FILE_APPEND);
    });
    answer(array('handlers_installed' => true));
    break;
case 'oom':
    register_shutdown_function(function () {
        file_put_contents(EVIDENCE_DIR . '/oom.shutdown.marker', (string)getmypid() . "\n");
    });
    class OomCleanup {
        public function __destruct() {
            file_put_contents(EVIDENCE_DIR . '/oom.destructor.marker', (string)getmypid() . "\n");
        }
    }
    $cleanup = new OomCleanup;
    started('oom');
    $buffer = str_repeat('x', 32 * 1024 * 1024);
    echo 'UNREACHABLE';
    break;
default:
    answer(array('unknown_action' => $action));
}

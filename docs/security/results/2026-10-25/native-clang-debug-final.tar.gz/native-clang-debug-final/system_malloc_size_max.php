<?php
if (!php56_probe_arm_atexit("/work/.security-build/results/native-clang-debug-final/system_malloc_size_max.native-atexit.marker")) { exit(90); }
register_shutdown_function(function () { file_put_contents("/work/.security-build/results/native-clang-debug-final/system_malloc_size_max.php-shutdown.marker", "php-shutdown\n"); });
php56_probe_boundary("system_malloc_size_max");

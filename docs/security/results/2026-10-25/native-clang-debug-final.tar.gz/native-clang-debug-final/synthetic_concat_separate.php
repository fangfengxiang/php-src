<?php
if (!php56_probe_arm_atexit("/work/.security-build/results/native-clang-debug-final/synthetic_concat_separate.native-atexit.marker")) { exit(90); }
register_shutdown_function(function () { file_put_contents("/work/.security-build/results/native-clang-debug-final/synthetic_concat_separate.php-shutdown.marker", "php-shutdown\n"); });
php56_probe_boundary("synthetic_concat_separate");

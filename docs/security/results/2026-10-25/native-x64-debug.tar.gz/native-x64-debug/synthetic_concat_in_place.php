<?php
if (!php56_probe_arm_atexit("/work/.security-build/results/native-x64-debug/synthetic_concat_in_place.native-atexit.marker")) { exit(90); }
register_shutdown_function(function () { file_put_contents("/work/.security-build/results/native-x64-debug/synthetic_concat_in_place.php-shutdown.marker", "php-shutdown\n"); });
php56_probe_boundary("synthetic_concat_in_place");
